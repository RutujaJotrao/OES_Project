<?php
include("header.php");
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title></title>

        <!-- Bootstrap Core CSS -->
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
        <link href="../css/metisMenu.min.css" rel="stylesheet">

        <!-- DataTables CSS -->
        <link href="../css/dataTables/dataTables.bootstrap.css" rel="stylesheet">

        <!-- DataTables Responsive CSS -->
        <link href="../css/dataTables/dataTables.responsive.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="../css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
        
  <div id="page-wrapper"> 
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="col-xs-12 text-center" style="margin-top: 5%;">
                <p class="lead" style="text-align: center;">Hello Students, <span >Have A Nice Day !</span></p>
           
        </div>
                        </div>
                        
                    <div class="row">
            <div class="col-xs-12" style="text-align: center;">
                <img src="images/banner.jpg" class="img-responsive banner-img">
            </div>
        </div>
                   <hr>
        
    </div>
                        </div>
                        
                            </div>
                        </div>    
                </div>
                
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->
    
</html>
<?php
include("footer.php");
?>